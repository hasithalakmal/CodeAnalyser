/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hasitha Lakmal
 */
public class SampleCode4 {

    public void checkCC(String x) {
        System.out.println(x);
        if ("a".equals(x)) {
            if (x.length() == 5) {
                System.out.println(x);
            } else {
                System.out.println(x);
            }
        } else if ("b".equals(x)) {
            System.out.println(x);
        } else {
            System.out.println(x);
        }
        
        System.out.println("jjjjj");
        
        for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }
    }

}
