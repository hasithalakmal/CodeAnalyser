/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hasitha Lakmal
 */
public class SampleCode1 {//25
    
    public void checkCC(String x){//65
        System.out.println(x);
        if("a".equals(x)){//123
            if(x.length()== 5){//155
                System.out.println(x);
            }//208
            else{//213
                System.out.println(x);
            }//266
        }//276
        else if("b".equals(x)){//299
            System.out.println(x);
        }//344
        else{//349
            System.out.println(x);
        }//394
    }//400
    
}//407
