/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hasitha Lakmal
 */
public class SampleCode2 {

    public void checkCC(String x) {
        System.out.println(x);
        if ("a".equals(x)) {
            if (x.length() == 5) {
                System.out.println(x);
            }
            else {
                System.out.println(x);
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {

                            } else {
                            }
                        } else {
                        }
                    } else {
                    }
                } else {
                }
            }
        }
        else if ("b".equals(x)) {
            System.out.println(x);
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {

                            } else {
                            }
                        } else if (true) {

                        } else if (true) {

                        } else if (true) {

                        } else if (true) {

                        } else {
                        }
                    } else {
                    }
                } else {
                }
            } else {
            }
        }
        else {
            System.out.println(x);
            if (true) {

            } else {
            }
            if (true) {

            } else {
            }
            if (true) {

            } else {
            }
            if (true) {

            } else {
            }
        }

        if (true) {

        } else {
        }
        if (true) {

        } else {
        }
        if (true) {

        } else {
        }
    }

}
