/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hasitha Lakmal
 */
public class SampleCode5 {

    int var1, var2, var3;
    String var4, var5, var6;
    int var7 = 5;

    public void checkCC(String var10) {
        System.out.println(var10);
        int var8 = 9;

        if ("a".equals(var10)) {
            String var9 = "hasitha";
            System.out.println();
            if (var10.length() == 5) {
                System.out.println(var10);
                System.out.println( var2 );
            } else {
                System.out.println(var10);
                System.out.println( var3);
            }
        } else if ("b".equals(var10)) {
            System.out.println(var10);
        } else {
            System.out.println(var10);
        }

        System.out.println("jjjjj");

        for (int itt = 0; itt < 10; itt++) {
            System.out.println(itt);
            System.out.println(var4);
        }
    }

}
