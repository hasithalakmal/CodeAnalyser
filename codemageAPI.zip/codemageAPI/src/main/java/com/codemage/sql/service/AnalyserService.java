package com.codemage.sql.service;



public interface AnalyserService {

	String getAnalysereport(String javaCode);
	
}
