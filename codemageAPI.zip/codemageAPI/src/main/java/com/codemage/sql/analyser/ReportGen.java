package com.codemage.sql.analyser;

public interface ReportGen {

    String getReport(String parameterValues);
    
}
