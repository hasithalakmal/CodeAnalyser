public class SampleCode3 {
    public void test(){
        System.out.println("Hello world");
    }
}
